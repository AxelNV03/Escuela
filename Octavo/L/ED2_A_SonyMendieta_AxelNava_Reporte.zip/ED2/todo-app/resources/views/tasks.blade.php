@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Panel de Tareas</h1>

    <!-- Formulario para agregar tareas -->
    <div id="task-form"></div>

    <!-- Lista de tareas -->
    <div id="task-list"></div>
</div>
@endsection
import React from 'react';
import ReactDOM from 'react-dom';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';

// Renderizar el formulario de tareas
if (document.getElementById('task-form')) {
    ReactDOM.render(<TaskForm />, document.getElementById('task-form'));
}

// Renderizar la lista de tareas
if (document.getElementById('task-list')) {
    ReactDOM.render(<TaskList />, document.getElementById('task-list'));
}
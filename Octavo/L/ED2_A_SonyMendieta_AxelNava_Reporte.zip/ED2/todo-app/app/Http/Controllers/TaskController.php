<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    // Obtener todas las tareas del usuario autenticado
    public function index()
    {
        $tasks = auth()->user()->tasks;
        return response()->json($tasks);
    }

    // Crear una nueva tarea
    public function store(Request $request)
    {
        $task = auth()->user()->tasks()->create($request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]));
        return response()->json($task, 201);
    }

    // Actualizar una tarea existente
    public function update(Request $request, Task $task)
    {
        $task->update($request->validate([
            'title' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'completed' => 'sometimes|boolean',
        ]));
        return response()->json($task);
    }

    // Eliminar una tarea
    public function destroy(Task $task)
    {
        $task->delete();
        return response()->json(null, 204);
    }
}
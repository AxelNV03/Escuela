

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Panel de Tareas</h1>

    <!-- Formulario para agregar tareas -->
    <div id="task-form"></div>

    <!-- Lista de tareas -->
    <div id="task-list"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\sonyc\Desktop\ED2\todo-app\resources\views/tasks.blade.php ENDPATH**/ ?>
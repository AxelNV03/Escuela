 generation)
    mostrarPoblacion(startPoblation)

    #Seleccion
    selectedPoblation = sele